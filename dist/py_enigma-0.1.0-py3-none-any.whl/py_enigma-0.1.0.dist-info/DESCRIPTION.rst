Py-enigma is a Python Client for the enigma.io V2 API


